#[derive(Debug, PartialEq)]
struct Cola<T, const N: usize>{
    a: [T; N],
    first: u32,
    last: u32,
    len: usize
}

impl<T: Default + Copy, const N: usize> Cola<T, N> {
    fn new() -> Self {
        Cola {
            a: [T::default(); N],
            first: 0,
            last: 0,
            len: 0
        }
    }

    fn len(&self) -> usize {
        self.len
    }

    fn enqueue(&mut self, n: T) -> Result<u32, String> {
        if self.len == N {
            return Err(String::from("Cola llena"));
        } else {
            self.a[self.last as usize] = n;
            self.len += 1;
            self.last = (self.last + 1) % N as u32;
            Ok(self.last)
        }
    }

    fn dequeue(&mut self) -> Result<T, String> {
        if self.len == 0 {
            return Err(String::from("Cola vacía"));
        } else {
            let n = self.a[self.first as usize];
            self.len -= 1;
            self.first = (self.first + 1) % N as u32;
            Ok(n)
        }
    }

    // NUEVA: inserta al frente (a la izquierda de `first`)
    fn enqueue_front(&mut self, n: T) -> Result<u32, String> {
        if self.len == N {
            return Err(String::from("Cola llena"));
        } else {
            // retrocedemos el índice first de forma circular
            self.first = (self.first + N as u32 - 1) % N as u32;
            self.a[self.first as usize] = n;
            self.len += 1;
            Ok(self.first)
        }
    }

    // NUEVA: elimina desde el final (a la izquierda de `last`)
    fn dequeue_back(&mut self) -> Result<T, String> {
        if self.len == 0 {
            return Err(String::from("Cola vacía"));
        } else {
            // retrocedemos last una posición circularmente
            self.last = (self.last + N as u32 - 1) % N as u32;
            let n = self.a[self.last as usize];
            self.len -= 1;
            Ok(n)
        }
    }
}

#[test]
fn test_enqueue_front_simple() {
    let mut q: Cola<&str, 4> = Cola::new();

    let _ = q.enqueue("B");
    let _ = q.enqueue("C");
    assert_eq!(q.a, ["B", "C", "", ""]); // Estado inicial
    assert_eq!(q.first, 0);
    assert_eq!(q.last, 2);
    assert_eq!(q.len(), 2);

    // Insertamos al frente "A"
    let _ = q.enqueue_front("A");

    // Ahora "A" está justo antes de "B"
    // Recuerda que los índices son circulares, así que first pasa a 3
    assert_eq!(
        q,
        Cola {
            a: ["B", "C", "", "A"],
            first: 3,
            last: 2,
            len: 3
        }
    );
}

#[test]
fn test_enqueue_front_wrap_around() {
    let mut q: Cola<&str, 4> = Cola::new();

    // Llenamos parcialmente y desplazamos first hacia la derecha
    let _ = q.enqueue("X");
    let _ = q.enqueue("Y");
    let _ = q.dequeue(); // saca "X", ahora first = 1
    assert_eq!(q.first, 1);
    assert_eq!(q.last, 2);

    // Insertamos delante con wrap-around
    let _ = q.enqueue_front("A");
    // Al insertar delante, first retrocede circularmente a 0
    assert_eq!(
        q,
        Cola {
            a: ["A", "Y", "", ""],
            first: 0,
            last: 2,
            len: 2
        }
    );
}

#[test]
fn test_dequeue_back_simple() {
    let mut q: Cola<&str, 4> = Cola::new();

    let _ = q.enqueue("A");
    let _ = q.enqueue("B");
    let _ = q.enqueue("C");

    assert_eq!(q.len(), 3);
    assert_eq!(q.first, 0);
    assert_eq!(q.last, 3);

    // Quitamos desde atrás
    let v = q.dequeue_back().unwrap();
    assert_eq!(v, "C");
    assert_eq!(q.len(), 2);
    assert_eq!(q.last, 2);

    // Quitamos otra vez desde atrás
    let v = q.dequeue_back().unwrap();
    assert_eq!(v, "B");
    assert_eq!(q.len(), 1);
    assert_eq!(q.last, 1);

    // Solo queda "A"
    assert_eq!(
        q,
        Cola {
            a: ["A", "B", "C", ""],
            first: 0,
            last: 1,
            len: 1
        }
    );
}

#[test]
fn test_enqueue_front_and_dequeue_back_combined() {
    let mut q: Cola<&str, 5> = Cola::new();

    let _ = q.enqueue("B");
    let _ = q.enqueue("C");
    let _ = q.enqueue_front("A");
    let _ = q.enqueue("D");

    // A, B, C, D en ese orden lógico
    assert_eq!(q.len(), 4);
    assert_eq!(q.dequeue_back().unwrap(), "D");
    assert_eq!(q.dequeue_back().unwrap(), "C");
    assert_eq!(q.dequeue().unwrap(), "A");
    assert_eq!(q.dequeue().unwrap(), "B");
    assert_eq!(q.len(), 0);
}


#[test]
fn test_enqueue_front() {
    let mut q: Cola<i32, 4> = Cola::new();
    let _ = q.enqueue(10);
    let _ = q.enqueue(20);
    let _ = q.enqueue_front(5);
    assert_eq!(q.a, [10, 20, 0, 5]);
    assert_eq!(q.first, 3);
    assert_eq!(q.last, 2);
    assert_eq!(q.len(), 3);
}

#[test]
fn test_dequeue_back() {
    let mut q: Cola<i32, 4> = Cola::new();
    let _ = q.enqueue(10);
    let _ = q.enqueue(20);
    let _ = q.enqueue(30);

    let v = q.dequeue_back().unwrap();
    assert_eq!(v, 30);
    assert_eq!(q.len(), 2);

    let v = q.dequeue_back().unwrap();
    assert_eq!(v, 20);
    assert_eq!(q.len(), 1);
}

#[test]
fn test_enqueue_front_and_dequeue_back_mix() {
    let mut q: Cola<&str, 4> = Cola::new();
    let _ = q.enqueue("A");
    let _ = q.enqueue("B");
    let _ = q.enqueue_front("Z");
    assert_eq!(q.dequeue_back().unwrap(), "B");
    assert_eq!(q.dequeue().unwrap(), "Z");
    assert_eq!(q.dequeue().unwrap(), "A");
}
